/****************************************************************************/
/*                                                                          */
/* Victory Device C-Interpreter Function Templates.                         */
/* Victory Device Version 1.20.0.R                                          */
/* Copyright (c) 2002-2022                                                  */
/* Silvaco Inc.  All rights reserved.                                       */
/*                                                                          */
/****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
#include <malloc.h>
#include <string.h>
#include "template.h"

/*
 * Position dependent net doping.
 * Statement: DOPING
 * Parameter: F.DOPING
 * Arguments:
 *   x     [input]  - location x (microns)
 *   y     [input]  - location y (microns)
 *   z     [input]  - location z (microns)
 *
 *   *nnet [return] - net doping concentration (per cc)
 */

int doping(double x,double y, double z, double *nnet)
{
	*nnet = CIgetNodalDouble(CI_NODAL_HYDROGEN_CONCENTRATION);

	return(0);                /* 0 - ok */
}


